
package com.example.superpowers;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.fabricmc.fabric.api.networking.v1.ClientPlayNetworking;
import net.minecraft.util.PacketByteBufs;

public class ClientMod implements ClientModInitializer {
    private static KeyBinding keybindToggle1;
    private static KeyBinding keybindToggle2;
    private static KeyBinding keybindToggle3;
    private static KeyBinding keybindToggle4;
    private static KeyBinding keybindToggle5;
    private static KeyBinding keybindToggle6;

    @Override
    public void onInitializeClient() {
        keybindToggle1 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.superpowers.toggle1", GLFW.GLFW_KEY_1, "category.superpowers"));
        keybindToggle2 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.superpowers.toggle2", GLFW.GLFW_KEY_2, "category.superpowers"));
        keybindToggle3 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.superpowers.toggle3", GLFW.GLFW_KEY_3, "category.superpowers"));
        keybindToggle4 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.superpowers.toggle4", GLFW.GLFW_KEY_4, "category.superpowers"));
        keybindToggle5 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.superpowers.toggle5", GLFW.GLFW_KEY_5, "category.superpowers"));
        keybindToggle6 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.superpowers.toggle6", GLFW.GLFW_KEY_6, "category.superpowers"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (keybindToggle1.wasPressed()) sendToggle(1);
            while (keybindToggle2.wasPressed()) sendToggle(2);
            while (keybindToggle3.wasPressed()) sendToggle(3);
            while (keybindToggle4.wasPressed()) sendToggle(4);
            while (keybindToggle5.wasPressed()) sendToggle(5);
            while (keybindToggle6.wasPressed()) sendToggle(6);
        });
    }

    private void sendToggle(int id) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(id);
        ClientPlayNetworking.send(new Identifier("superpowers","toggle"), buf);
        // Note: no client-side UI/feedback implemented here to keep example small
    }
}
