
package com.example.superpowers;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.fabricmc.fabric.api.networking.v1.PacketSender;

public class ServerMod implements ModInitializer {
    public static final Identifier TOGGLE_PACKET = new Identifier("superpowers", "toggle");

    @Override
    public void onInitialize() {
        ServerPlayNetworking.registerGlobalReceiver(TOGGLE_PACKET, (server, player, handler, buf, responseSender) -> {
            int powerId = buf.readInt();
            server.execute(() -> {
                NbtCompound data = player.getPersistentData();
                String key = "superpower_" + powerId;
                boolean current = data.getBoolean(key);
                data.putBoolean(key, !current);
                // Optionally: send feedback packet back to client (omitted for brevity)
            });
        });

        // Each tick, apply effect to players who enabled powers
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                NbtCompound data = player.getPersistentData();
                // Super Jump (powerId = 1)
                if (data.getBoolean("superpower_1")) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 40, 4, false, false, true));
                    player.fallDistance = 0.0F; // reduce fall damage clientside too
                }
                // Super Speed (powerId = 2)
                if (data.getBoolean("superpower_2")) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 2, false, false, true));
                }
                // Fire Power (powerId = 3) - fire resistance + set enemies on fire is more complex; we give fire resistance
                if (data.getBoolean("superpower_3")) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 40, 0, false, false, true));
                }
                // Super Strength (powerId = 4)
                if (data.getBoolean("superpower_4")) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, 1, false, false, true));
                }
                // Invincibility (powerId = 5) - give resistance high level
                if (data.getBoolean("superpower_5")) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, 4, false, false, true));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 40, 4, false, false, true));
                }
                // Dash (powerId = 6) - implemented clientside when key pressed (server cannot detect double-tap easily here)
            }
        });
    }
}
