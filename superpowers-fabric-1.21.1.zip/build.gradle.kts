
plugins {
    id("fabric-loom") version "1.2.11" // You may update this to a newer loom release if needed
    id("maven-publish")
    java
}

repositories {
    mavenCentral()
    maven { url = uri("https://maven.fabricmc.net/") }
    maven { url = uri("https://repo.spongepowered.org/maven") }
}

val minecraft_version: String by project
val yarn_mappings: String by project
val loader_version: String by project
val fabric_api_version: String by project

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(21))
}

dependencies {
    minecraft("com.mojang:minecraft:${'$'}{minecraft_version}")
    mappings("net.fabricmc:yarn:${'$'}{yarn_mappings}:v2")
    modImplementation("net.fabricmc:fabric-loader:${'$'}{loader_version}")
    modImplementation("net.fabricmc.fabric-api:fabric-api:${'$'}{fabric_api_version}")
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.release.set(21)
}
