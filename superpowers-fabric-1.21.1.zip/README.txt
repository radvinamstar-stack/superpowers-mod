
Superpowers - Fabric mod (1.21.1)
=================================

What you get:
- Ready-to-build Fabric mod project for Minecraft 1.21.1 (src, resources, build files)
- A small example resource pack (resourcepack/) containing an icon
- README with build instructions and notes

Important notes (please read):
- I cannot compile Java/Gradle in this chat environment (no JDK/Gradle here). This ZIP contains the full project so you can build on your PC or CI.
- Recommended Java: Java 21 (Minecraft 1.21.x and Fabric tooling increasingly require modern Java versions). See Fabric docs for details.  (citation in chat)
- This mod uses Fabric Loom and Fabric API. If you update versions, consult Fabric docs / example mod templates. (citation in chat)

Quick build instructions (local):
1) Install JDK 21+ (Temurin/Adoptium recommended)
2) Install Gradle or use the Gradle wrapper (you can run `./gradlew build` on Unix or `gradlew.bat build` on Windows)
3) From the project root run: ./gradlew build
   The compiled mod jar will be under build/libs/ (e.g. superpowers-1.0.0.jar)
4) Put the jar into your Minecraft mods folder (with Fabric Loader 1.21.1 installed and Fabric API matching the version)

If you don't want to build locally:
- You can create a GitHub repo from this project and add the included GitHub Actions workflow (example below) to build and produce an artifact automatically.
- Or ask me to produce a GitHub Actions workflow file and I will add it into the repo files (it's included in this ZIP).

Security & testing:
- The code applies effects server-side so it should work on both singleplayer (integrated server) and multiplayer servers where you have mod installed.
- The dash ability is left as a client-side placeholder; feel free to request a follow-up to expand dash into a full server-validated impulse.

Useful links:
- Fabric docs (Loom & setup): https://docs.fabricmc.net/develop/loom/ . citeturn0search2
- Fabric example mod repo (template): https://github.com/FabricMC/fabric-example-mod . citeturn0search8
- Installing Java for modern Minecraft versions (advice): Fabric docs installation notes. citeturn1search2

------------------
Files included:
- build.gradle.kts, gradle.properties, settings.gradle.kts
- src/main/java/com/example/superpowers/ServerMod.java
- src/main/java/com/example/superpowers/ClientMod.java
- src/main/resources/fabric.mod.json
- src/main/resources/assets/... (model, texture, lang)
- resourcepack/ (simple resourcepack with icon)
- README (this file)
